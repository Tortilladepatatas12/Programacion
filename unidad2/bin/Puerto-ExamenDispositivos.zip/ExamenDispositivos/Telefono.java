package ExamenDispositivos;

public class Telefono extends Dispositivo {

	public Telefono(String marca, String modelo, double precio) {
		super(marca, modelo, precio);
		// TODO Auto-generated constructor stub
	}

	private boolean TieneTecladoFisico;
	
}
