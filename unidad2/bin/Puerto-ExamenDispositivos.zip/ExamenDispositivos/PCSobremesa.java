package ExamenDispositivos;

public class PCSobremesa extends Computadora {

	public PCSobremesa(String marca, String modelo, double precio) {
		super(marca, modelo, precio);
		// TODO Auto-generated constructor stub
	}

	private boolean tieneGPUdedicada;
	
}
