package ExamenDispositivos;

public class Computadora extends Dispositivo {

	public Computadora(String marca, String modelo, double precio) {
		super(marca, modelo, precio);
		// TODO Auto-generated constructor stub
	}

	private int capacidadRAM; 
	
}
